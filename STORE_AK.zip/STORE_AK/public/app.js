let catalog = {};
let storeRIP = "";
let selectedProduct = null;

async function api(url, options={}) {
  const token = localStorage.getItem("storeak_token");
  options.headers = {"Content-Type":"application/json", ...(options.headers||{})};
  if (token) options.headers.Authorization = "Bearer " + token;
  const r = await fetch(url, options);
  const data = await r.json().catch(()=>({}));
  if (!r.ok) throw new Error(data.error || "حدث خطأ");
  return data;
}

async function init(){
  catalog = await api("/api/catalog");
  const info = await api("/api/payment-info");
  storeRIP = info.baridimob.rip || "";
  document.getElementById("ripNumber").value = storeRIP || "غير متوفر";
  renderGames();
  document.getElementById("provider").addEventListener("change", updatePayment);
  updatePayment();
}
function renderGames(){
  const grid = document.getElementById("gamesGrid");
  grid.innerHTML = Object.entries(catalog).map(([id,p]) => `
    <article class="card">
      <h3>${p.name}</h3>
      <p>${p.field}</p>
      <button onclick="openProduct('${id}')">اختيار الباقة</button>
    </article>`).join("");
}
function openProduct(id){
  selectedProduct = id;
  const p = catalog[id];
  document.getElementById("modalTitle").textContent = p.name;
  document.getElementById("productId").value = id;
  document.getElementById("playerLabel").textContent = p.field;
  document.getElementById("packageId").innerHTML = p.packages.map(x=>`<option value="${x[0]}">${x[1]} — ${x[2]} دج</option>`).join("");
  document.getElementById("formMsg").textContent = "";
  document.getElementById("modal").classList.remove("hidden");
}
function closeModal(){document.getElementById("modal").classList.add("hidden")}
async function createOrder(e){
  e.preventDefault();
  const msg = document.getElementById("formMsg");
  try{
    const email = document.getElementById("email").value.trim().toLowerCase();
    const password = document.getElementById("password").value;
    const productId = document.getElementById("productId").value;
    const packageId = document.getElementById("packageId").value;
    const playerRef = document.getElementById("playerRef").value.trim();

    let token = localStorage.getItem("storeak_token");
    if(!token){
      try { await api("/api/register",{method:"POST",body:JSON.stringify({email,password})}); } catch(err) {}
      const login = await api("/api/login",{method:"POST",body:JSON.stringify({email,password})});
      token = login.token; localStorage.setItem("storeak_token", token);
    }
    const order = await api("/api/orders",{method:"POST",body:JSON.stringify({productId,packageId,playerRef})});
    const provider = document.getElementById("provider").value;
    const ref = prompt(`تم إنشاء الطلب #${order.orderId} بمبلغ ${order.amountDzd} دج.\nبعد الدفع، أدخل مرجع العملية:`);
    if(!ref) { msg.textContent="تم إنشاء الطلب. أكمل الدفع ثم أرسل المرجع من صفحة الطلبات/الدعم."; return; }
    await api(`/api/orders/${order.orderId}/payment`,{method:"POST",body:JSON.stringify({provider,providerRef:ref.trim()})});
    msg.textContent=`تم تسجيل الدفع للطلب #${order.orderId}. الحالة: قيد التحقق.`;
    document.getElementById("paymentMessage").textContent=`الطلب #${order.orderId}: في انتظار تأكيد الدفع.`;
  }catch(err){ msg.textContent=err.message; }
}
async function copyRIP(){
  if(!storeRIP) return;
  await navigator.clipboard.writeText(storeRIP);
  alert("تم نسخ RIP");
}
function updatePayment(){
  const provider=document.getElementById("provider").value;
  document.getElementById("baridiBox").style.display=provider==="BARIDIMOB"?"block":"none";
}
document.getElementById("orderForm").addEventListener("submit",createOrder);
init().catch(e=>alert(e.message));