async function load(){
 const token=localStorage.getItem("storeak_token");
 const el=document.getElementById("admin");
 if(!token){el.innerHTML="<p>لا يوجد تسجيل دخول.</p>";return}
 const r=await fetch("/api/admin/orders",{headers:{Authorization:"Bearer "+token}});
 const data=await r.json();
 if(!r.ok){el.innerHTML="<p>"+(data.error||"غير مصرح")+"</p>";return}
 el.innerHTML=data.map(o=>`<div class="card" style="margin:12px 0">
 <h3>طلب #${o.id} — ${o.product_id}</h3>
 <p>العميل: ${o.email} | المبلغ: ${o.amount_dzd} دج</p>
 <p>الحالة: ${o.status} | الشحن: ${o.delivery_status}</p>
 <p>مرجع الدفع: ${o.provider_ref||"—"}</p>
 ${o.status!=="PAID"?`<button onclick="confirmPay(${o.id})">تأكيد الدفع</button>`:""}
 ${o.status==="PAID"&&o.delivery_status!=="DELIVERED"?`<button onclick="deliver(${o.id})">تسجيل الشحن</button>`:""}
 </div>`).join("")||"<p>لا توجد طلبات.</p>";
}
async function act(url){
 const token=localStorage.getItem("storeak_token");
 const r=await fetch(url,{method:"POST",headers:{Authorization:"Bearer "+token}});
 const d=await r.json(); if(!r.ok) alert(d.error||"خطأ"); load();
}
function confirmPay(id){act("/api/admin/orders/"+id+"/confirm-payment")}
function deliver(id){act("/api/admin/orders/"+id+"/mark-delivered")}
load();